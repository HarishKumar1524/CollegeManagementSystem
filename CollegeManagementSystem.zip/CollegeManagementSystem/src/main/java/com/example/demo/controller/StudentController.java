package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.entity.Student;
import com.example.demo.error.NotFoundException;
import com.example.demo.repository.StudentRepository;
import com.example.demo.service.StudentService;

@RestController

public class StudentController {
	@Autowired
	
	private StudentService studentservice;
	
	@Autowired
	private StudentRepository studentRepository;
	
	@PostMapping("student")
	public ResponseEntity<Student> addStudent(@Valid @RequestBody Student student) {
		Student student1=studentservice.addStudent(student);
		return new ResponseEntity<>(student1,HttpStatus.CREATED);
		
	}
	

	
	@GetMapping("student")
	public List<Student> getAllStudents(){
		return studentservice.getAllStudents();
	}

	@GetMapping("student/{sid}")
	public Student getStudentById(@PathVariable("sid") Integer sid) throws NotFoundException {
		return  studentservice.getStudentById(sid);
	}
	
	@DeleteMapping("student/{sid}")
	
	public String deleteStudentById(@PathVariable("sid") Integer sid) throws NotFoundException {
		
		studentservice.deleteStudentById(sid);
		return "record is deleted";
	}
	
	@PutMapping("student/{sid}")
	
	public Student updateStudent(@PathVariable("sid") Integer sid, @RequestBody Student student ) throws NotFoundException {
		return studentservice.updateStudent(sid,student);
		
	}
	
	@GetMapping("/studenttotalfees")
	 public float studenttotalfees() {
		 return studentRepository.totalFees();
	 }
}
