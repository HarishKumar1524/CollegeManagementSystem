package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Teacher;
import com.example.demo.error.NotFoundException;


public interface TeacherService {

	Teacher addTeacher(Teacher teacher);

	List<Teacher> getAllTeacher();

	Teacher getTeacherById(Integer tid, Teacher teacher) throws NotFoundException;

	void deleteTeacher(Integer tid) throws NotFoundException;

	Teacher updateTeacher(Integer tid, Teacher teacher) throws NotFoundException;

}
