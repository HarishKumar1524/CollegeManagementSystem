package com.example.demo.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity

public class Teacher {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	
	private Integer teacherId;
	
	@NotEmpty(message="teacher name should not be empty")
	private String teacherName;
	
	@Min(value=1000,message="salery should greater than 1000")
	private float teacherSalery;
	
	
	
@JsonIgnore
	
	@OneToMany(mappedBy = "teacher")
	private Set<Subject>subject=new HashSet<>();




	public Set<Subject> getSubject() {
	return subject;
}
public void setSubject(Set<Subject> subject) {
	this.subject = subject;
}
	public Integer getTeacherId() {
		return teacherId;
	}
	public void setTeacherId(Integer teacherId) {
		this.teacherId = teacherId;
	}
	
	
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	public float getTeacherSalery() {
		return teacherSalery;
	}
	public void setTeacherSalery(float teacherSalery) {
		this.teacherSalery = teacherSalery;
	}
	
	
	

}
